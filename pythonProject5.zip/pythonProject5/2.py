def three_args(*, var1=None, var2=None, var3=None):
    args = []
    if var1 is not None:
        args.append(f"var1 = {var1}")
    if var2 is not None:
        args.append(f"var2 = {var2}")
    if var3 is not None:
        args.append(f"var3 = {var3}")

    if args:
        args_string = ", ".join(args)
        print(f"Переданы аргументы: {args_string}")


# пример

three_args(var1=2, var3=10)
