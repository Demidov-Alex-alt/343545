def count_words(text):
    words = text.split()

    word_counts = {}
    for word in words:
        word = word.strip('.,!?').lower()
        if word:
            if word in word_counts:
                word_counts[word] += 1
            else:
                word_counts[word] = 1

    most_common_word = max(word_counts, key=word_counts.get)

    longest_word = max(words, key=len)

    return most_common_word, longest_word


text = input("Введите текст: ")

most_common, longest = count_words(text)
print("Наиболее часто встречающееся слово:", most_common)
print("Самое длинное слово:", longest)
